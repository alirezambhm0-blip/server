/**
 * STEP 12 — تست جریان خروج
 * ثابت می‌کند پاک‌سازی کوکی در سرور *پیش از* reload کامل می‌شود،
 * وگرنه مرورگر درخواست را abort می‌کرد و کاربر لاگین می‌ماند.
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const ADMIN = process.env.ADMIN_DIR || (__dirname + '/../files/wholesale-api/public/admin');
const coreSrc = fs.readFileSync(ADMIN + '/core.js', 'utf8');
const appSrc = fs.readFileSync(ADMIN + '/app.js', 'utf8');

let pass = 0, fail = 0;
function check(name, cond, detail) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '\n          ' + detail : '')); }
}

const events = [];
let logoutResolved = false;

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
  url: 'http://localhost:3000/admin/index.html',
  runScripts: 'dangerously',
  // window.location در jsdom غیرقابل بازتعریف است؛ با beforeParse پیش از اجرای
  // هر اسکریپتی، reload را روی نمونهٔ location نصب می‌کنیم.
  beforeParse(window) {
    window.location.reload = () => events.push('RELOAD');
    window.URL.createObjectURL = () => 'blob:stub';
    window.URL.revokeObjectURL = () => {};
  },
});
const win = dom.window;

// fetch که پاک شدن کوکی را با تاخیر شبیه‌سازی می‌کند
win.fetch = function (path, opts) {
  events.push('fetch:' + path);
  if (String(path).indexOf('/auth/logout') === 0) {
    return new Promise((resolve) => setTimeout(() => {
      logoutResolved = true;
      events.push('logout-response-received');
      resolve({ status: 200, ok: true, headers: { get: () => 'application/json' }, json: () => Promise.resolve({}) });
    }, 20));
  }
  return Promise.resolve({ status: 200, ok: true, headers: { get: () => 'application/json' }, json: () => Promise.resolve({}) });
};

const s = win.document.createElement('script');
s.textContent = coreSrc;
win.document.body.appendChild(s);

(async () => {
  console.log('── ترتیب خروج ──');

  const FAKE_JWT = 'legacy.jwt.token';
  win.localStorage.setItem('admin_token_v3', FAKE_JWT);

  const p = win.clearAuthToken();
  check('clearAuthToken یک Promise برمی‌گرداند', p && typeof p.then === 'function',
    'نوع بازگشتی: ' + typeof p);

  // دقیقاً همان الگویی که دکمهٔ خروج و هندلر 401 استفاده می‌کنند
  await Promise.resolve(p).then(function () { events.push('RELOAD'); });

  check('درخواست /auth/logout ارسال شد', events.includes('fetch:/auth/logout'), JSON.stringify(events));
  check('پاسخ پاک‌سازی کوکی *پیش از* reload دریافت شد',
    events.indexOf('logout-response-received') < events.indexOf('RELOAD'),
    'ترتیب: ' + JSON.stringify(events));
  check('توکن میراثی از localStorage حذف شد', win.localStorage.getItem('admin_token_v3') === null);

  console.log('');
  console.log('── مقایسه با رفتار پیش از اصلاح ──');
  console.log('  ترتیب واقعی ثبت‌شده: ' + JSON.stringify(events));
  console.log('  (پیش از اصلاح، RELOAD بلافاصله و بدون انتظار رخ می‌داد)');

  console.log('');
  console.log('── هندلر 401 هم await می‌کند ──');
  const src401 = fs.readFileSync(ADMIN + '/core.js', 'utf8');
  check('هندلر 401 از Promise.resolve(clearAuthToken()).then استفاده می‌کند',
    /Promise\.resolve\(clearAuthToken\(\)\)\.then\(function\(\)\{location\.reload\(\);\}\)/.test(src401));
  check('دکمهٔ خروج هم await می‌کند',
    /Promise\.resolve\(clearAuthToken\(\)\)\.then\(function\(\) \{ location\.reload\(\); \}\)/.test(appSrc));

  console.log('');
  console.log('═══════════ نتیجه ═══════════');
  console.log('  ' + pass + ' PASS / ' + fail + ' FAIL');
  process.exit(fail === 0 ? 0 : 1);
})();
