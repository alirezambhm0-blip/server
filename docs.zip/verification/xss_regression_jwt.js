/**
 * STEP 16 — رگرسیون امنیتی XSS برای P1-4
 *
 * روش: core.js *واقعیِ پروژه* را در یک DOM واقعی (jsdom) بارگذاری می‌کند،
 * یک fetch ضبط‌کننده جایگزین می‌کند، و سپس بررسی می‌کند که درخواست‌های ادمین
 * هیچ هدر Authorization نمی‌سازند — حتی وقتی یک JWT زنده در localStorage کاشته شده.
 *
 * این آزمون مستقیماً همان سناریوی حملهٔ پیش از فاز را بازسازی می‌کند:
 *   XSS → JavaScript → localStorage → سرقت JWT
 */
const fs = require('fs');
const { JSDOM } = require('jsdom');

const ADMIN = process.env.ADMIN_DIR || __dirname + '/../files/wholesale-api/public/admin';
const coreSrc = fs.readFileSync(ADMIN + '/core.js', 'utf8');

let pass = 0, fail = 0;
function check(name, cond, detail) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (detail ? '\n          ' + detail : '')); }
}

// ── ساخت محیط: jsdom + fetch ضبط‌کننده ─────────────────────────────
const calls = [];
const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
  url: 'http://localhost:3000/admin/index.html',
  runScripts: 'dangerously',
});
const win = dom.window;
win.fetch = function (path, opts) {
  calls.push({ path, opts: opts || {} });
  return Promise.resolve({
    status: 200,
    ok: true,
    headers: { get: () => 'application/json' },
    json: () => Promise.resolve({ ok: true }),
    blob: () => Promise.resolve(new win.Blob(['x'])),
  });
};
// jsdom این دو را پیاده نکرده؛ صرفاً برای ادامهٔ مسیر secureBlob stub می‌شوند.
win.URL.createObjectURL = () => 'blob:stub';
win.URL.revokeObjectURL = () => {};

// core.js را به‌صورت یک <script> واقعی تزریق می‌کنیم.
// دلیل: core.js با 'use strict' شروع می‌شود و در حالت strict، eval یک scope
// جدید می‌سازد پس اعلان توابع به window نشت نمی‌کند. تزریق به‌صورت script
// دقیقاً همان چیزی است که مرورگر در index.html:12 انجام می‌دهد.
const scriptEl = win.document.createElement('script');
scriptEl.textContent = coreSrc;
win.document.body.appendChild(scriptEl);

const FAKE_JWT = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhdHRhY2tlciJ9.signature';

console.log('=== محیط ===');
console.log('  core.js واقعی پروژه در jsdom بارگذاری شد');
console.log('  fetch با ضبط‌کننده جایگزین شد تا هدرهای ارسالی بازرسی شوند');
console.log('');

// ── ۱) حتی با JWT کاشته‌شده در localStorage، هدر Authorization ساخته نمی‌شود ──
console.log('── سناریوی حمله: JWT زنده در localStorage کاشته شده ──');
win.localStorage.setItem('admin_token_v3', FAKE_JWT);
check('پیش‌شرط: توکن در localStorage کاشته شد', win.localStorage.getItem('admin_token_v3') === FAKE_JWT);

(async () => {
  await win.api('/admin/dashboard');
  const c = calls[calls.length - 1];
  const hdrs = c.opts.headers || {};
  const hasAuth = Object.keys(hdrs).some(k => k.toLowerCase() === 'authorization');

  check('api() هیچ هدر Authorization نمی‌سازد', !hasAuth, 'هدرها: ' + JSON.stringify(hdrs));
  check('api() توکن را در هیچ هدری نمی‌فرستد',
    !JSON.stringify(hdrs).includes(FAKE_JWT), 'توکن در هدرها دیده شد!');
  check('api() credentials:include دارد (کوکی خودکار ارسال می‌شود)', c.opts.credentials === 'include');
  check('URL ارسالی شامل توکن نیست', !String(c.path).includes(FAKE_JWT));

  // ── ۲) secureBlob هم همین‌طور ──
  console.log('');
  console.log('── secureBlob (بارگذاری مدارک KYC) ──');
  await win.secureBlob('/files/kyc/x.jpg');
  const c2 = calls[calls.length - 1];
  const hdrs2 = c2.opts.headers || {};
  check('secureBlob() هیچ هدر Authorization نمی‌سازد',
    Object.keys(hdrs2).length === 0 || !Object.keys(hdrs2).some(k => k.toLowerCase() === 'authorization'),
    'هدرها: ' + JSON.stringify(hdrs2));
  check('secureBlob() credentials:include دارد', c2.opts.credentials === 'include');

  // ── ۳) توابع حذف‌شده دیگر وجود ندارند ──
  console.log('');
  console.log('── توابع ناامن باید حذف شده باشند ──');
  check('getAuthToken دیگر وجود ندارد', typeof win.getAuthToken === 'undefined');
  check('setAuthToken دیگر وجود ندارد', typeof win.setAuthToken === 'undefined');
  check('getCookie دیگر وجود ندارد', typeof win.getCookie === 'undefined');

  // ── ۴) clearAuthToken توکن میراثی را پاک می‌کند ──
  console.log('');
  console.log('── پاک‌سازی توکن میراثی (migration) ──');
  win.localStorage.setItem('admin_token_v3', FAKE_JWT);
  win.clearAuthToken();
  check('clearAuthToken توکن باقی‌مانده از نسخهٔ قبل را حذف می‌کند',
    win.localStorage.getItem('admin_token_v3') === null);

  // ── ۵) هیچ مسیر JS-خواندنی دیگری برای توکن نمانده ──
  console.log('');
  console.log('── ممیزی نهایی فضای JS ──');
  const globalsWithToken = Object.keys(win).filter(k => {
    try {
      const v = win[k];
      return typeof v === 'string' && v.includes(FAKE_JWT);
    } catch (e) { return false; }
  });
  check('هیچ متغیر سراسری شامل توکن نیست', globalsWithToken.length === 0,
    'متغیرها: ' + JSON.stringify(globalsWithToken));

  check('sessionStorage خالی است', win.sessionStorage.length === 0);

  console.log('');
  console.log('═══════════ نتیجه ═══════════');
  console.log('  ' + pass + ' PASS / ' + fail + ' FAIL');
  console.log('═════════════════════════════');
  console.log('');
  console.log('نتیجهٔ امنیتی: یک payload XSS در پنل ادمین دیگر نمی‌تواند');
  console.log('توکن احراز هویت را از localStorage / sessionStorage / متغیر سراسری');
  console.log('بخواند یا آن را از طریق هدرهای درخواست ربایش کند.');
  process.exit(fail === 0 ? 0 : 1);
})();
