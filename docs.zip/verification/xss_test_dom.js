const vm = require('vm');
const fs = require('fs');
const { JSDOM } = require('jsdom');

const ADMIN = process.env.ADMIN_DIR || __dirname + '/../files/wholesale-api/public/admin';

// ۱) esc() واقعی از core.js پروژه
const core = fs.readFileSync(ADMIN + '/core.js', 'utf8');
const escSrc = core.match(/function esc\(s\)\{[^\n]*\n/)[0];
const ctx = {};
vm.createContext(ctx);
vm.runInContext(escSrc + '\nthis.esc = esc;', ctx);
const esc = ctx.esc;

// ۲) عبارات واقعی از فایل‌های patch‌شده (مستقیم از دیسک)
const EXPR_APP = fs.readFileSync(__dirname + '/EXPR_APP.txt', 'utf8').trim();
const EXPR_ORD = fs.readFileSync(__dirname + '/EXPR_ORD.txt', 'utf8').trim();

console.log('=== محیط آزمون ===');
console.log('  esc() از core.js واقعی پروژه بارگذاری شد');
console.log('  عبارت‌ها مستقیماً از app.js / orders.js پچ‌شده خوانده شدند');
console.log('  ارزیابی با jsdom (DOM واقعی مرورگر)');
console.log('');

let pass = 0, fail = 0;

/**
 * آزمون قطعی: HTML را در یک DOM واقعی پارس می‌کند.
 * اگر payload توانسته باشد تگ یا event handler بسازد، اینجا لو می‌رود.
 */
function assertSafe(name, html, expectedText) {
  const dom = new JSDOM('<table><tbody><tr>' + html + '</tr></tbody></table>');
  const doc = dom.window.document;

  const problems = [];

  // ۱) هیچ المان قابل‌اجرا/ناخواسته‌ای نباید ساخته شود
  ['img', 'script', 'svg', 'iframe', 'object', 'embed', 'link', 'style'].forEach(tag => {
    const n = doc.getElementsByTagName(tag);
    if (n.length > 0) problems.push(`المان <${tag}> ساخته شد (${n.length})`);
  });

  // ۲) هیچ attribute رویداد (on*) روی هیچ المانی نباید باشد
  doc.querySelectorAll('*').forEach(el => {
    for (const a of el.attributes) {
      if (/^on/i.test(a.name)) problems.push(`handler ${a.name} روی <${el.tagName.toLowerCase()}>`);
      if (/^\s*javascript:/i.test(a.value)) problems.push(`javascript: در ${a.name}`);
    }
  });

  // ۳) متن payload باید به‌عنوان *متن* قابل مشاهده باقی بماند
  if (expectedText) {
    const visible = doc.body.textContent;
    if (visible.indexOf(expectedText) < 0) problems.push('payload به‌صورت متن دیده نمی‌شود');
  }

  if (problems.length === 0) {
    pass++;
    console.log('  PASS  ' + name);
  } else {
    fail++;
    console.log('  FAIL  ' + name);
    problems.forEach(p => console.log('          ✗ ' + p));
    console.log('          HTML: ' + html.slice(0, 150));
  }
}

console.log('── STEP 14: payload مهاجم باید بی‌اثر و به‌صورت متن رندر شود ──');
const P1 = '<img src=x onerror=alert(1)>';
const P2 = '"><script>alert(1)</script>';
const P3 = "';alert(1);//";
const P4 = '<svg/onload=alert(1)>';
const P5 = '<iframe src="javascript:alert(1)"></iframe>';

[P1, P2, P3, P4, P5].forEach((p, i) => {
  var e = { userId: p };
  assertSafe(`P0-1  userId = ${p.slice(0, 34)}`, eval(EXPR_APP), p);
});

function buildOrd(s, f, l) {
  var o = { customerId: 'X', customer: { storeName: s, firstName: f, lastName: l } };
  return eval(EXPR_ORD);
}
[P1, P2, P3, P4, P5].forEach(p => {
  assertSafe(`P0-2  storeName = ${p.slice(0, 30)}`, buildOrd(p, 'علی', 'رضایی'), p);
  assertSafe(`P0-2  firstName = ${p.slice(0, 30)}`, buildOrd('فروشگاه', p, 'رضایی'), p);
  assertSafe(`P0-2  lastName  = ${p.slice(0, 30)}`, buildOrd('فروشگاه', 'علی', p), p);
});

// fallback باید حفظ شود
(function () {
  var e = {};
  const html = eval(EXPR_APP);
  if (html.indexOf('مهمان') >= 0) { pass++; console.log('  PASS  P0-1  fallback «مهمان» برای userId خالی حفظ شد'); }
  else { fail++; console.log('  FAIL  P0-1  fallback «مهمان» از دست رفت: ' + html); }
})();

console.log('');
console.log('── STEP 15: رگرسیون — مقادیر مشروع باید دست‌نخورده نمایش داده شوند ──');
const legit = [
  ['نام فارسی', 'فروشگاه برادران احمدی', 'علی', 'رضایی'],
  ['نام انگلیسی', 'Bonko Market Store', 'John', 'Smith'],
  ['فاصله‌های متعدد', 'سوپر مارکت  شهر', 'مریم', 'کریمی'],
  ['علائم نگارشی', 'فروشگاه آ.ب.پ', 'سید', 'م.-رضایی'],
  ['اعداد فارسی', 'فروشگاه ۱۲۳', '۴۵۶', '۷۸۹'],
  ['یونیکد/ایموجی', '🏪 فروشگاه مرکزی', '👤', '⭐'],
  ['کاراکترهای HTML-مانندِ مشروع', 'فروشگاه <بزرگ>', 'a&b', "o'neill"],
  ['رشتهٔ خالی', '', '', ''],
  ['null/undefined', null, undefined, null],
];
let regOk = 0;
for (const [label, s, f, l] of legit) {
  const html = buildOrd(s, f, l);
  const dom = new JSDOM('<div>' + html + '</div>');
  const text = dom.window.document.body.textContent;
  const expected = [s, f, l].filter(v => v !== null && v !== undefined && v !== '').map(String);
  // ساختار <br>/<small> باید حفظ شود
  const structureOk = html.indexOf('<br>') >= 0 && html.indexOf('<small') >= 0;
  // هر مقدار مشروع باید جداگانه و دست‌نخورده در متن نهایی دیده شود
  const norm = t => String(t).replace(/\s+/g, ' ').trim();
  const textN = norm(text);
  const missing = expected.filter(v => textN.indexOf(norm(v)) < 0);
  const contentOk = missing.length === 0;
  if (structureOk && contentOk) { regOk++; console.log('  PASS  ' + label + '   →  «' + text.trim() + '»'); }
  else { fail++; console.log('  FAIL  ' + label + '  structure=' + structureOk + ' missing=' + JSON.stringify(missing)); console.log('        ' + html.slice(0, 150)); }
}

console.log('');
console.log('═══════════ نتیجه ═══════════');
console.log('  payload مهاجم : ' + pass + ' PASS / ' + fail + ' FAIL');
console.log('  رگرسیون مشروع : ' + regOk + ' / ' + legit.length);
console.log('═════════════════════════════');
process.exit(fail === 0 && regOk === legit.length ? 0 : 1);
